package com.project.java;

public abstract class Instrument
{
public abstract void Play();
}